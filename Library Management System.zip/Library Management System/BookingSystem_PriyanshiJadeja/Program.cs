﻿using System.Diagnostics;

namespace BookingSystem_PriyanshiJadeja
{
    internal class Program
    {

        const int MaxBooks = 100;

        static string[] titles = new string[MaxBooks];
        static string[] authors = new string[MaxBooks];
        static string[] isbns = new string[MaxBooks];
        static string[] prices = new string[MaxBooks];
        static string[] categories = new string[MaxBooks];
       
        static int bookCount = 0;

        enum BookCategory
        {
            Fiction,
            NonFiction,
            Science,
            History,
            Biography,
            Technology
        }

        struct Book
        {
            public string Title;
            public string Author;
            public string ISBN;
            public decimal Price;
            public BookCategory Category;

            public Book(string title, string author, string isbn, decimal price, BookCategory category)
            {
                Title = title;
                Author = author;
                ISBN = isbn;
                Price = price;
                Category = category;
            }
        }

        static void Main(string[] args)
        {

            CreateBookRecords();
            LoadFromFile();
            DisplayMenu();
        }

        static void DisplayMenu()
        {
            bool runLoop = true;
            while (runLoop)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nLibrary Management System");
                Console.WriteLine("1. Add Book");
                Console.WriteLine("2. Display All Books");
                Console.WriteLine("3. Search Book by ISBN");
                Console.WriteLine("4. Remove Book by ISBN");
                Console.WriteLine("5. Save and Exit");
                Console.Write("Choose an option: ");
                int userChoice = Convert.ToInt32(Console.ReadLine());
                Console.ForegroundColor = ConsoleColor.White;

                switch (userChoice)

                {

                    case 1:
                        AddBook();
                        break;
                    case 2:
                        Console.WriteLine();
                        DisplayBooks();

                        break;
                    case 3:
                        Console.WriteLine();
                        Console.Write("Enter ISBN to search: ");
                        string isbn = Convert.ToString(Console.ReadLine());
                        SearchBook(isbn);
                        break;
                    case 4:
                        Console.WriteLine();
                        Console.Write("Enter ISBN to remove: ");
                        string isbn1 = Convert.ToString(Console.ReadLine());
                        RemoveBook(isbn1);
                        break;
                    case 5:
                        SaveToFile();
                        runLoop = false;
                        Console.WriteLine("Exiting...");
                        break;
                    default:
                        Console.WriteLine("Invalid option. Please try again.");
                        break;
                }
            }
        }
        
        static void AddBook()
        {
            if(bookCount <= MaxBooks)
            {

                Console.Write("Enter the Title you want to enter: ");
                titles[bookCount] = Console.ReadLine();
                if (titles[bookCount] == null)
                {
                    Console.WriteLine("Please enter valid title number");
                }

                Console.Write("Enter the author of your book: ");
                authors[bookCount] = Console.ReadLine();
                if (authors[bookCount] == null)
                {
                    Console.WriteLine("Please enter valid author name");
                }

                Console.Write("Enter ISBN Number : ");
                isbns[bookCount] = Console.ReadLine();
                if (isbns[bookCount] == null)
                {
                    Console.WriteLine("Please enter valid ISBN number");
                }

                Console.Write("Enter Price: ");
                prices[bookCount] = Console.ReadLine();
                if (prices[bookCount] == null)
                {
                    Console.WriteLine("Please enter valid price");
                }


                Console.WriteLine("Enter Category (Fiction, NonFiction, Thriller, Science, Technology, Biography): ");
                categories[bookCount] = Console.ReadLine();

                bookCount++;
                Console.WriteLine("Congrats! The book has been added successfully.");
            }
            else
            {
                Console.WriteLine("No of max books limit has been reached!");
            }
        }

        static void DisplayBooks()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            if (bookCount == 0)
            {
                Console.WriteLine("Please Add any book in the library.");
                return;
            }
            Console.ForegroundColor = ConsoleColor.White;

            for (int i = 0; i < bookCount; i++)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"Title: {titles[i]}");
                Console.WriteLine($"Author: {authors[i]}");
                Console.WriteLine($"ISBN: {isbns[i]}");
                Console.WriteLine($"Price: $ {prices[i]}");
                Console.WriteLine($"Category: {categories[i]}");
                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.White;
            }
        }
        static void SearchBook(string isbn)
        {
            bool findBook = false;
            for (int i = 0; i < bookCount; i++)
            {
                if (isbns[i] == isbn)
                {
                    Console.WriteLine($"Book found: \nTitle: {titles[i]}, Author: {authors[i]}, ISBN: {isbns[i]}, Price: {prices[i]:C}, Category: {categories[i]}");
                    findBook = true;
                    break;
                }
            }

            if (findBook == false)
            {
                Console.WriteLine("Book not found.");
            }
        }

        static void RemoveBook(string isbn)
        {
            int index = -1;
            for (int i = 0; i < bookCount; i++)
            {

                if (isbns[i] == isbn)
                {
                    index = i;
                    break;
                }
            }

            if (index == -1)
            {
                Console.WriteLine("Book not found.");
                return;
            }

            for (int i = index; i < bookCount - 1; i++)
            {
                titles[i] = titles[i + 1];
                authors[i] = authors[i + 1];
                isbns[i] = isbns[i + 1];
                prices[i] = prices[i + 1];
                categories[i] = categories[i + 1];
            }

            bookCount--;
            Console.WriteLine("Book removed successfully.");
        }

        static void SaveToFile()
        {
            using (StreamWriter writer = new StreamWriter("books.txt"))
            {
                for (int i = 0; i < bookCount; i++)
                {
                    writer.WriteLine($"{titles[i]},{authors[i]},{isbns[i]},{prices[i]},{categories[i]}");
                }
            }
            Console.WriteLine("Books saved to file.");

            DisplayBooks();
        }
        static void CreateBookRecords()
        {
            string filePath = "books.txt";
            if (File.Exists(filePath))
            {
                File.Delete(filePath);
            }


            string[] predefinedBooks = new string[10]
            {
        "The Great Gatsby,F. Scott Fitzgerald,9780743273565,10.99,Fiction",
        "Sapiens,Yuval Noah Harari,9780062316097,15.50,NonFiction",
        "A Brief History of Time,Stephen Hawking,9780553380163,12.95,Science",
        "The Diary of a Young Girl,Anne Frank,9780553296983,7.95,History",
        "Steve Jobs,Walter Isaacson,9781451648539,14.99,Biography",
        "The Innovators,Walter Isaacson,9781476708706,16.99,Technology",
        "1984,George Orwell,9780451524935,9.99,Fiction",
        "Homo Deus,Yuval Noah Harari,9780062464316,17.99,NonFiction",
        "Cosmos,Carl Sagan,9780345539434,13.50,Science",
        "The Wright Brothers,David McCullough,9781476728759,11.99,History"
            };

            using (StreamWriter writer = new StreamWriter(filePath))
            {
                foreach (var book in predefinedBooks)
                {
                    writer.WriteLine(book);
                }
            }
        }

        static void LoadFromFile()
        {
            if (File.Exists("books.txt"))
            {
                using (StreamReader reader = new StreamReader("books.txt"))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        var parts = line.Split(',');
                        titles[bookCount] = parts[0];
                        authors[bookCount] = parts[1];
                        isbns[bookCount] = parts[2];
                        prices[bookCount] = parts[3];
                        categories[bookCount] = parts[4];
                        bookCount++;
                    }
                }
                Console.WriteLine("Sample Book Records has been created and loaded from file.");
            }
            else
            {
                Console.WriteLine("No saved books found.");
            }

        }
    }
}

