﻿namespace HorseRacingGame
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            labelFinish = new Label();
            buttonStart = new Button();
            timer1 = new System.Windows.Forms.Timer(components);
            labelLeader = new Label();
            pictureBoxHorse1 = new PictureBox();
            pictureBoxHorse2 = new PictureBox();
            pictureBoxHorse3 = new PictureBox();
            panelHorseRaceTrack = new Panel();
            panel3 = new Panel();
            panel1 = new Panel();
            panel2 = new Panel();
            ((System.ComponentModel.ISupportInitialize)pictureBoxHorse1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxHorse2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxHorse3).BeginInit();
            panelHorseRaceTrack.SuspendLayout();
            SuspendLayout();
            // 
            // labelFinish
            // 
            labelFinish.BackColor = SystemColors.ActiveCaption;
            labelFinish.Location = new Point(934, 13);
            labelFinish.Margin = new Padding(2, 0, 2, 0);
            labelFinish.Name = "labelFinish";
            labelFinish.Size = new Size(51, 352);
            labelFinish.TabIndex = 7;
            labelFinish.Text = "\r\n\r\n\r\n     F\r\n     I\r\n     N\r\n     I\r\n     S\r\n    H";
            // 
            // buttonStart
            // 
            buttonStart.Location = new Point(13, 382);
            buttonStart.Margin = new Padding(2);
            buttonStart.Name = "buttonStart";
            buttonStart.Size = new Size(90, 27);
            buttonStart.TabIndex = 4;
            buttonStart.Text = "Start Race";
            buttonStart.UseVisualStyleBackColor = true;
            buttonStart.Click += buttonStart_Click;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // labelLeader
            // 
            labelLeader.AutoSize = true;
            labelLeader.Location = new Point(225, 385);
            labelLeader.Margin = new Padding(2, 0, 2, 0);
            labelLeader.Name = "labelLeader";
            labelLeader.Size = new Size(50, 20);
            labelLeader.TabIndex = 6;
            labelLeader.Text = "label1";
            // 
            // pictureBoxHorse1
            // 
            pictureBoxHorse1.Image = Properties.Resources.Horse1;
            pictureBoxHorse1.Location = new Point(2, 0);
            pictureBoxHorse1.Margin = new Padding(2);
            pictureBoxHorse1.Name = "pictureBoxHorse1";
            pictureBoxHorse1.Size = new Size(97, 72);
            pictureBoxHorse1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxHorse1.TabIndex = 0;
            pictureBoxHorse1.TabStop = false;
            // 
            // pictureBoxHorse2
            // 
            pictureBoxHorse2.Image = Properties.Resources.Cow;
            pictureBoxHorse2.Location = new Point(2, 117);
            pictureBoxHorse2.Margin = new Padding(2);
            pictureBoxHorse2.Name = "pictureBoxHorse2";
            pictureBoxHorse2.Size = new Size(97, 74);
            pictureBoxHorse2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxHorse2.TabIndex = 1;
            pictureBoxHorse2.TabStop = false;
            // 
            // pictureBoxHorse3
            // 
            pictureBoxHorse3.Image = Properties.Resources.Rhino;
            pictureBoxHorse3.Location = new Point(2, 231);
            pictureBoxHorse3.Margin = new Padding(2);
            pictureBoxHorse3.Name = "pictureBoxHorse3";
            pictureBoxHorse3.Size = new Size(97, 75);
            pictureBoxHorse3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxHorse3.TabIndex = 2;
            pictureBoxHorse3.TabStop = false;
            // 
            // panelHorseRaceTrack
            // 
            panelHorseRaceTrack.Controls.Add(panel3);
            panelHorseRaceTrack.Controls.Add(panel1);
            panelHorseRaceTrack.Controls.Add(pictureBoxHorse3);
            panelHorseRaceTrack.Controls.Add(pictureBoxHorse2);
            panelHorseRaceTrack.Controls.Add(pictureBoxHorse1);
            panelHorseRaceTrack.Location = new Point(11, 11);
            panelHorseRaceTrack.Margin = new Padding(2);
            panelHorseRaceTrack.Name = "panelHorseRaceTrack";
            panelHorseRaceTrack.RightToLeft = RightToLeft.No;
            panelHorseRaceTrack.Size = new Size(974, 354);
            panelHorseRaceTrack.TabIndex = 3;
            // 
            // panel3
            // 
            panel3.BackColor = SystemColors.Highlight;
            panel3.Location = new Point(2, 301);
            panel3.Name = "panel3";
            panel3.Size = new Size(926, 32);
            panel3.TabIndex = 5;
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.Highlight;
            panel1.Location = new Point(0, 69);
            panel1.Name = "panel1";
            panel1.Size = new Size(926, 32);
            panel1.TabIndex = 3;
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.Highlight;
            panel2.Location = new Point(11, 194);
            panel2.Name = "panel2";
            panel2.Size = new Size(926, 32);
            panel2.TabIndex = 4;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ScrollBar;
            ClientSize = new Size(996, 434);
            Controls.Add(panel2);
            Controls.Add(labelFinish);
            Controls.Add(labelLeader);
            Controls.Add(buttonStart);
            Controls.Add(panelHorseRaceTrack);
            Margin = new Padding(2);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)pictureBoxHorse1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxHorse2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxHorse3).EndInit();
            panelHorseRaceTrack.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button buttonStart;
        private System.Windows.Forms.Timer timer1;
        private Label labelFinish;
        private Label labelLeader;
        private PictureBox pictureBoxHorse1;
        private PictureBox pictureBoxHorse2;
        private PictureBox pictureBoxHorse3;
        private Panel panelHorseRaceTrack;
        private Panel panel1;
        private Panel panel3;
        private Panel panel2;
    }
}
