using System.Drawing.Printing;

namespace HorseRacingGame
{
    public partial class Form1 : Form
    {
        private Random random = new Random();
        public Form1()
        {
            InitializeComponent();
            random = new Random();
        }

        

        private void buttonStart_Click(object sender, EventArgs e)
        {
            pictureBoxHorse1.Left = 0;
            pictureBoxHorse2.Left = 0;
            pictureBoxHorse3.Left = 0;
            labelLeader.Text = "Race is on!";
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int step1 = random.Next(0, 10);
            int step2 = random.Next(0, 10);
            int step3 = random.Next(0, 10);

            pictureBoxHorse1.Left += step1;
            pictureBoxHorse2.Left += step2;
            pictureBoxHorse3.Left += step3;

            UpdateLeadingHorse();
            RaceFinish();
        }

        private void RaceFinish()
        {
            if (pictureBoxHorse1.Right >= labelFinish.Left)
            {
                Reset();
                MessageBox.Show("Donkey is the winner");
                labelLeader.Text = "Donkey is the winner";
                
            }
            else if (pictureBoxHorse2.Right >= labelFinish.Left)
            {
                Reset();
                MessageBox.Show("Cow is the winner");
                labelLeader.Text = "Cow is the winner";
               
            }
            else if (pictureBoxHorse3.Right >= labelFinish.Left)
            {
                Reset();
                MessageBox.Show("Rhino is the winner");
                labelLeader.Text = "Rhino is the winner";
                
            }
        }

        private void Reset()
        {
            timer1.Stop();  
            pictureBoxHorse1.Left = 0;
            pictureBoxHorse2.Left = 0;
            pictureBoxHorse3.Left = 0;
            labelLeader.Text = "Press start to begin the race";
        }

        private void UpdateLeadingHorse()
        {
            int horse1 = pictureBoxHorse1.Left;
            int horse2 = pictureBoxHorse2.Left;
            int horse3 = pictureBoxHorse3.Left;

            if (horse1 > horse2 && horse1 > horse3)
            {
                labelLeader.Text = "Donkey is leading";
            }
            else if (horse2 > horse1 && horse2 > horse3)
            {
                labelLeader.Text = "Cow is leading";
            }
            else if (horse3 > horse1 && horse3 > horse2)
            {
                labelLeader.Text = "Rhino is leading";
            }
            else
            {
                labelLeader.Text = "It's a Tie!";
            }
        }
    }
}
