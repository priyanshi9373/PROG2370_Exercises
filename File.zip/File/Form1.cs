namespace PriyanshiJadeja_Midterm_GameProgramming
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void save(String fileName, int totalNumber)
        {
            StreamWriter writer = new StreamWriter(fileName);
            writer.WriteLine(totalNumber);
            Random random = new Random();
            for (int i = 0; i < totalNumber; i++)
            {
                writer.WriteLine(random.Next(0, 100));
            }

            writer.Close();
        }
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult r = dlgSave.ShowDialog();
            MessageBox.Show(r.ToString());

            switch (r)
            {
                case DialogResult.Cancel:
                    MessageBox.Show("File has not Saved");
                    break;
                case DialogResult.OK:
                    try
                    {
                        int totalNumbers = int.Parse(txtNumber.Text);
                        MessageBox.Show(dlgSave.FileName);
                        save(dlgSave.FileName, totalNumbers);
                        MessageBox.Show($"File has saved successfull at {dlgSave.FileName}");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error in Saving File " + ex.Message);
                    }
                    break;
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Thank you for Using Application", "Exit");
            Close();
        }

        public void load(String fileName)
        {
            StreamReader streamReader = new StreamReader(fileName);

            while (!streamReader.EndOfStream)
            {
                Console.WriteLine(streamReader.ReadLine());
            }

            streamReader.Close();
        }

        private void loadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dlgLoad.Filter = "Text File |*.txt |Image Files|*.jpg|All Files|*.*";
            DialogResult r = dlgLoad.ShowDialog();
            switch (r)
            {
                case DialogResult.OK:
                    load(dlgLoad.FileName);
                    break;
            }
        }
    }
}
