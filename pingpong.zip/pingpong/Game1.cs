﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace pingpong
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;

        private Texture2D _paddleTexture;
        private Vector2 _leftPaddlePosition, _rightPaddlePosition;
        private float _paddleSpeed = 5f;

        //ball properties
        private Texture2D _ballTexture;
        private Vector2 _ballPosition;
        private Vector2 _ballVelocity;

        //screen properties
        private int _screenHeight;
        private int _screenWidth;

        //score Properties
        private int _leftScore, _rightScore;
        private SpriteFont _font;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            _screenHeight = _graphics.PreferredBackBufferHeight = 500;
            _screenWidth = _graphics.PreferredBackBufferWidth = 800;
            _graphics.ApplyChanges();

            //Initial Position of the Paddles
            _leftPaddlePosition = new Vector2(10, _screenHeight / 2 - 50);
            _rightPaddlePosition = new Vector2(_screenWidth - 30, _screenHeight / 2 - 50);
            _ballPosition = new Vector2(_screenWidth / 2, _screenHeight / 2);
            _ballVelocity = new Vector2(4, 4);

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            //Load Texture 
            _paddleTexture = new Texture2D(GraphicsDevice, 20, 100);
            _ballTexture = new Texture2D(GraphicsDevice, 20, 20);
            _font = Content.Load<SpriteFont>("fonts/simplefont");

            //Create paddle texture 
            Color[] paddledata = new Color[20*100];
            for(int i = 0; i < paddledata.Length; i++)
                paddledata[i] = Color.White;    
                _paddleTexture.SetData(paddledata);

            //create ball texture
            Color[] ballData = new Color[20 * 20];
            for (int i = 0; i < ballData.Length; i++)
                ballData[i] = Color.White;
            _ballTexture.SetData(ballData);
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here
            KeyboardState state = Keyboard.GetState();

            //left paddle controlls (W = Up, S = Down)
            if (state.IsKeyDown(Keys.W) && _leftPaddlePosition.Y > 0)
            {
                _leftPaddlePosition.Y -= _paddleSpeed;
            }
            if (state.IsKeyDown(Keys.S) && _leftPaddlePosition.Y < _screenHeight - 100)
            {
                _leftPaddlePosition.Y += _paddleSpeed;  
            }

            //right paddle controls (Up Arrow = Up, Down Arrow = Down)
            if (state.IsKeyDown(Keys.Up) && _rightPaddlePosition.Y > 0)
            {
                _rightPaddlePosition.Y -= _paddleSpeed;
            }
            if (state.IsKeyDown(Keys.Down) && _leftPaddlePosition.Y < _screenHeight - 100)
            {
                _rightPaddlePosition.Y += _paddleSpeed;
            }

            //ball movement
            _ballPosition += _ballVelocity;

            //ball has collion at top or bottom
            if(_ballPosition.Y <= 0 ||  _ballPosition.Y >= _screenHeight - 20)
            {
                _ballVelocity.Y = -_ballVelocity.Y;
            }

            //ball collision wih paddles
            Rectangle ballRect = new Rectangle((int)_ballPosition.X, (int)_ballPosition.Y, 20, 20);
            Rectangle leftPaddle = new Rectangle((int)_leftPaddlePosition.X, (int)_leftPaddlePosition.Y, 20, 100);
            Rectangle rightPaddle = new Rectangle((int)_rightPaddlePosition.X, (int)_rightPaddlePosition.Y, 20, 100);

            if (ballRect.Intersects(leftPaddle) || ballRect.Intersects(rightPaddle))
                _ballVelocity.X *= -1;

            if(_ballPosition.X <= 0)
            {
                _rightScore++;
                ResetGame();
            }
            if(_ballPosition.X >= _screenWidth - 20)
            {
                _leftScore++;
                ResetGame();
            }

            base.Update(gameTime);
        }

        private void ResetGame()
        {
            _ballPosition = new Vector2(_screenWidth / 2, _screenHeight / 2);    
            _ballVelocity = new Vector2(_ballVelocity.X * -1, _ballVelocity.Y * -1);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here
            _spriteBatch.Begin();
            _spriteBatch.Draw(_paddleTexture, _leftPaddlePosition, Color.Crimson);
            _spriteBatch.Draw(_paddleTexture, _rightPaddlePosition, Color.Azure);
            _spriteBatch.Draw(_ballTexture, _ballPosition, Color.White);
            _spriteBatch.DrawString(_font, $"Left Player : {_leftScore}", new Vector2(50, 10), Color.ForestGreen);
            _spriteBatch.DrawString(_font, $"Right Player : {_rightScore}", new Vector2(_screenWidth - 200, 10), Color.Azure);
            _spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
