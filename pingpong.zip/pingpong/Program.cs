﻿using var game = new pingpong.Game1();
game.Run();
