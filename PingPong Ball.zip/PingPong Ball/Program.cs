﻿using var game = new Assignment3_PriyanshiJadeja.Game1();
game.Run();
