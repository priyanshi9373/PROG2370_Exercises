﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;

namespace Assignment3_PriyanshiJadeja
{
    public class Ball : DrawableGameComponent
    {
        private SpriteBatch sb;
        private Texture2D tex;
        private Vector2 pos;
        private Vector2 speed;
        private SoundEffect hitSound;
        private SoundEffect missSound;
        private Rectangle boundary;
        private bool ballMissed;

        public Ball(Game game, SpriteBatch sb, Texture2D tex, SoundEffect hitSound, SoundEffect missSound, Rectangle boundary) : base(game)  
        {
            this.sb = sb;
            this.tex = tex;
            this.hitSound = hitSound;
            this.missSound = missSound;
            this.boundary = boundary;   

            pos = new Vector2(boundary.Width / 2, boundary.Height / 2);
            speed = new Vector2(3, 3);
            ballMissed = false;
        }

        public override void Update(GameTime gameTime)
        {
            pos += speed;
            if(pos.X <= 0 || pos.X + tex.Width >= boundary.Width)
            {
                speed.X = -speed.X;
                hitSound.Play();
            }
            if (pos.Y <= 0)
            {
                speed.Y = -speed.Y;
                hitSound.Play();
            }
            else if(pos.Y + tex.Height >= boundary.Height)
            {
                if (!ballMissed)
                {
                    missSound.Play();
                    ballMissed = true;
                }
            }

            base.Update(gameTime);
        }

        public override void Draw(GameTime gameTime)
        {
            sb.Begin();
            sb.Draw(tex, pos, Color.White);
            sb.End();

            base.Draw(gameTime);
        }

        public Rectangle getBounds()
        {
            return new Rectangle((int)pos.X, (int)pos.Y, tex.Width, tex.Height);
        }

        public void ReverseVerticalSpeed()
        {
            speed.Y = -speed.Y;
        }

    }
}
