﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Assignment3_PriyanshiJadeja
{
    public class Bat : DrawableGameComponent
    {
        private SpriteBatch sb;
        private Texture2D tex;
        private Vector2 pos;
        private Rectangle boundary;
        private float speed = 5f;

        public Bat(Game game, SpriteBatch sb, Texture2D tex, Rectangle boundary) : base(game)    
        {
            this.sb = sb;
            this.tex = tex;
            this.boundary = boundary;
            pos = new Vector2(boundary.Width / 2 - tex.Width / 2, boundary.Height - tex.Height - 10);
        }

        public override void Update(GameTime gameTime)
        {
            KeyboardState ks = Keyboard.GetState();
            if (ks.IsKeyDown(Keys.Left))
            {
                pos.X -= speed;
                if (pos.X < 0)
                {
                    pos.X = 0;
                }
            }
            if(ks.IsKeyDown(Keys.Right))
            {
                pos.X += speed;
                if (pos.X > boundary.Width - tex.Width)
                {

                    pos.X = boundary.Width - tex.Width;
                }
            }

            base.Update(gameTime);
        }

        public override void Draw(GameTime gameTime)
        {
            sb.Begin();
            sb.Draw(tex, pos, Color.White);
            sb.End();
            
            base.Draw(gameTime);
        }

        public Rectangle getBounds()
        {
            return new Rectangle((int)pos.X, (int)pos.Y, tex.Width, tex.Height);
        }
    }
}
