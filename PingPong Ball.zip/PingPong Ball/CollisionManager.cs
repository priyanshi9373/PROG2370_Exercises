﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3_PriyanshiJadeja
{
    public class CollisionManager : DrawableGameComponent
    {
        private Ball ball;
        private Bat bat;
        private SoundEffect hitSound;

        public CollisionManager(Game game, Ball ball, Bat bat, SoundEffect hitSound) : base(game)   
        {
            this.ball = ball;
            this.bat = bat;
            this.hitSound = hitSound;
        }   

        public override void Update(GameTime gameTime)
        {
            if(ball.getBounds().Intersects(bat.getBounds()))
            {
                ball.ReverseVerticalSpeed();
                hitSound.Play();
            }

            base.Update(gameTime);
        }
    }
}
