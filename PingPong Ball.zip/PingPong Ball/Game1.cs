﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Assignment3_PriyanshiJadeja
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        private Ball ball;
        private Bat bat;
        private CollisionManager collisionManager;
        private Song bgMusic;


        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            Texture2D texball = Content.Load<Texture2D>("Images/ball");
            Texture2D texbat = Content.Load<Texture2D>("Images/bat");
            SoundEffect hitSound = Content.Load<SoundEffect>("Sound/click");
            SoundEffect missSound = Content.Load<SoundEffect>("Sound/applause1");

            bgMusic = Content.Load<Song>("Sound/chimes");

            MediaPlayer.IsRepeating = true;
            MediaPlayer.Play(bgMusic);

            Rectangle boundary = GraphicsDevice.Viewport.Bounds;

            ball = new Ball(this, _spriteBatch, texball, hitSound, missSound, boundary);
            bat = new Bat(this, _spriteBatch, texbat, boundary);
            collisionManager = new CollisionManager(this, ball, bat, hitSound);

            Components.Add(ball);
            Components.Add(bat);
            Components.Add(collisionManager);
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.LightBlue);

            // TODO: Add your drawing code here
            _spriteBatch.Begin();
            _spriteBatch.End(); 

            base.Draw(gameTime);
        }
    }
}
